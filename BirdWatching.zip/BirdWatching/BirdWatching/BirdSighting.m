//
//  BirdSighting.m
//  BirdWatching
//
//  Created by xiaozhu on 27/10/13.
//  Copyright (c) 2013 Self. All rights reserved.
//

#import "BirdSighting.h"

@implementation BirdSighting

-(id)initWithName:(NSString *)name location:(NSString *)location date:(NSDate *)date
{
    self = [super init];
    if (self){
        _name = name;
        _location = location;
        _date = date;
//        self.name = name;
//        self.location = location;
//        self.date = date;
        return self;
    }
    return nil;

}

@end
