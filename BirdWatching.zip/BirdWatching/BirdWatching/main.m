//
//  main.m
//  BirdWatching
//
//  Created by xiaozhu on 27/10/13.
//  Copyright (c) 2013 Self. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BirdsAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BirdsAppDelegate class]));
    }
}
